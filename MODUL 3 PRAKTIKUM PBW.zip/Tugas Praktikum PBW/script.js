// buat navbar

const menuToggle = document.querySelector('.menu-toggle input');
const nav = document.querySelector('nav ul');

menuToggle.addEventListener("click", function(){
    nav.classList.toggle("slide");
});

// buat scroll top

function scrollKeatas(){
    window.scrollTo({
        top:0,
        behavior:"smooth"
    })
}

